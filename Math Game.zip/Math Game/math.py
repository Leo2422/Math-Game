import random

def generate_question(difficulty):
    num1 = random.randint(1, difficulty * 10)
    num2 = random.randint(1, difficulty * 10)
    operator = random.choice(["+", "-", "x", "/"])  
    
    if operator == "+":
        answer = num1 + num2
    elif operator == "-":
        num1, num2 = max(num1, num2), min(num1, num2)
        answer = num1 - num2
    elif operator == "x":
        answer = num1 * num2
    else:
        num1 = num1 * num2
        answer = num1 / num2
    
    if operator == "/":
        question = f"What is {num1} : {num2}?"
    else:
        question = f"What is {num1} {operator} {num2}?"
    
    return question, answer

def main():
    print("Welcome to the Math Game!")
    max_difficulty = 15  
    num_questions = 15

    while True:
        score = 0
        difficulty = 1  
        
        while difficulty <= max_difficulty:
            print(f"\nCurrent Difficulty: {difficulty}")
            
            for _ in range(num_questions):
                question, correct_answer = generate_question(difficulty)
                print(question)
                
                try:
                    user_answer = float(input("Your answer: "))  
                except ValueError:
                    print("Invalid input. Please enter a number.")
                    continue
                
                if user_answer == correct_answer:
                    print("Correct!\n")
                    score += 1
                    difficulty += 1  
                else:
                    print(f"Wrong! The correct answer is {correct_answer}.\n")
            
            print(f"Round Over! Your score is: {score}/{num_questions}")
            
            if difficulty > max_difficulty:
                print("You have reached the maximum difficulty level.")
                break
        
        print(f"Game Over! Your total score is: {score}")
        
        choice = input("Do you want to retry? (y/n): ").strip().lower()
        if choice != "y":
            break

if __name__ == "__main__":
    main()
